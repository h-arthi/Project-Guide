def map_vals(input_angle, inMax, inMin, outMax, outMin):
    input_angle = input_angle % 360 # make sure input angles are in the 360 range
    return outMin + (float(input_angle - inMin) / float(inMax - inMin) * (outMax- outMin))


if __name__ == '__main__':
    new_angle = map_vals(62.7933, 100, 0, 4, -4)
    print(round(new_angle, 2))
