# /*---------------------------------------------------------------------------------------------
#  * Copyright (c) 2022 STMicroelectronics.
#  * All rights reserved.
#  *
#  * This software is licensed under terms that can be found in the LICENSE file in
#  * the root directory of this software component.
#  * If no LICENSE file comes with this software, it is provided AS-IS.
#  *--------------------------------------------------------------------------------------------*/

from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.preprocessing.image import load_img
from tensorflow.keras.applications import imagenet_utils
from tensorflow.keras.models import Model
from PIL import Image
import imutils

import os
import cv2
import sys
from pathlib import Path
from omegaconf import DictConfig
from tabulate import tabulate
import numpy as np
import tensorflow as tf

import warnings
warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

from models_utils import get_model_name_and_its_input_shape, ai_runner_interp, ai_interp_input_quant, ai_interp_outputs_dequant
from models_mgt import ai_runner_invoke
from preprocess import preprocess_input
from onnx_evaluation import predict_onnx
import onnxruntime


class GradCAM:
    def __init__(self, model, classIdx, layerName=None):
        # store the model, the class index used to measure the class
        # activation map, and the layer to be used when visualizing
        # the class activation map
        self.model = model
        self.classIdx = classIdx
        self.layerName = layerName

        # if the layer name is None, attempt to automatically find
        # the target output layer
        if self.layerName is None:
            self.layerName = self.find_target_layer()

    def find_target_layer(self):
        # attempt to find the final convolutional layer in the network
        # by looping over the layers of the network in reverse order
        for layer in reversed(self.model.layers):
            # check to see if the layer has a 4D output
            if len(layer.output.shape) == 4:
                print(layer.name)
                return layer.name
            

        # otherwise, we could not find a 4D layer so the GradCAM
        # algorithm cannot be applied
        raise ValueError("Could not find 4D layer. Cannot apply GradCAM.")

    def compute_heatmap(self, image, eps=1e-8):
        # construct our gradient model by supplying (1) the inputs
        # to our pre-trained model, (2) the output of the (presumably)
        # final 4D layer in the network, and (3) the output of the
        # softmax activations from the model
        gradModel = Model(inputs=[self.model.inputs], outputs= [self.model.get_layer(self.layerName).output, self.model.output])

        # record operations for automatic differentiation
        with tf.GradientTape() as tape:
            # cast the image tensor to a float-32 data type, pass the
            # image through the gradient model, and grab the loss
            # associated with the specific class index
            inputs = tf.cast(image, tf.float32)
            (convOutputs, predictions) = gradModel(inputs)
            loss = predictions[:, self.classIdx]

        # use automatic differentiation to compute the gradients
        grads = tape.gradient(loss, convOutputs)

        # compute the guided gradients
        castConvOutputs = tf.cast(convOutputs > 0, "float32")
        castGrads = tf.cast(grads > 0, "float32")
        guidedGrads = castConvOutputs * castGrads * grads

        # the convolution and guided gradients have a batch dimension
        # (which we don't need) so let's grab the volume itself and
        # discard the batch
        convOutputs = convOutputs[0]
        guidedGrads = guidedGrads[0]

        # compute the average of the gradient values, and using them
        # as weights, compute the ponderation of the filters with
        # respect to the weights
        weights = tf.reduce_mean(guidedGrads, axis=(0, 1))
        cam = tf.reduce_sum(tf.multiply(weights, convOutputs), axis=-1)

        # grab the spatial dimensions of the input image and resize
        # the output class activation map to match the input image
        # dimensions
        (w, h) = (image.shape[2], image.shape[1])
        heatmap = cv2.resize(cam.numpy(), (w, h))

        # normalize the heatmap such that all values lie in the range
        # [0, 1], scale the resulting values to the range [0, 255],
        # and then convert to an unsigned 8-bit integer
        numer = heatmap - np.min(heatmap)
        denom = (heatmap.max() - heatmap.min()) + eps
        heatmap = numer / denom
        heatmap = (heatmap * 255).astype("uint8")

        # return the resulting heatmap to the calling function
        return heatmap

    def overlay_heatmap(self, heatmap, image, alpha=0.5,
        colormap=cv2.COLORMAP_JET):
        # apply the supplied color map to the heatmap and then
        # overlay the heatmap on the input image
        heatmap = cv2.applyColorMap(heatmap, colormap)
        output = cv2.addWeighted(image, alpha, heatmap, 1 - alpha, 0)

        # return a 2-tuple of the color mapped heatmap and the output,
        # overlaid image
        return (heatmap, output)

def visualize_gradcam(model, img_path, class_names, pred_index, predictions, preprocessed_image=None, target_size=(128, 128)):
    """
    Generate GradCAM visualization for a given model and image.
    
    Parameters:
    - model: Trained model (Keras/TF model)
    - img_path: Path to the original image
    - class_names: List of class names
    - pred_index: Index of the predicted class
    - predictions: Model predictions (already computed)
    - preprocessed_image: Already preprocessed image (optional)
    - target_size: Target size for image if preprocessing is needed
    
    Returns:
    - output: Final visualization image
    """
    # Load the original image from disk (in OpenCV format) for visualization
    orig = cv2.imread(img_path)
    
    # Check if preprocessed image is provided, otherwise preprocess it
    if preprocessed_image is None:
        # Load and preprocess the image
        image = load_img(img_path, target_size=target_size)
        image = img_to_array(image)
        image = np.expand_dims(image, axis=0)
        image = imagenet_utils.preprocess_input(image)
    else:
        # Use the provided preprocessed image, ensuring it has the right shape [1, height, width, channels]
        # or [1, channels, height, width] depending on data format
        image = preprocessed_image
        if len(image.shape) == 3:  # Add batch dimension if missing
            image = np.expand_dims(image, axis=0)
    
    # Get the predicted class name and probability
    class_name = class_names[pred_index]
    probability = predictions[pred_index] * 100
    label = f"{class_name}: {probability:.2f}%"
    print(f"[INFO] {label}")
    
    # initialize our gradient class activation map and build the heatmap
    cam = GradCAM(model, pred_index, layerName="top_conv")
    heatmap = cam.compute_heatmap(image)
    
    # resize the resulting heatmap to the original input image dimensions
    # and then overlay heatmap on top of the image
    heatmap = cv2.resize(heatmap, (orig.shape[1], orig.shape[0]))
    (heatmap, output) = cam.overlay_heatmap(heatmap, orig, alpha=0.5)
    
    # Draw the predicted label on the output image
    cv2.rectangle(output, (0, 0), (340, 40), (0, 0, 0), -1)
    cv2.putText(output, label, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    # display the original image and resulting heatmap and output image
    # to our screen
    output = np.vstack([orig, heatmap, output])
    output = imutils.resize(output, height=700)

    gradcam_result_dir = r'G:\My Drive\trained_quantized\thesis\better\grad-cam-copare\efficientnet'
    os.makedirs(gradcam_result_dir, exist_ok=True)
    grad_res_filename = f'{gradcam_result_dir}/{os.path.basename(img_path)}.png'
    cv2.imwrite(grad_res_filename,output)
    # cv2.imshow("Output", output)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    
    return output


def load_test_data(directory: str):
    """
    Parse the training data and return a list of paths to annotation files.
    
    Args:
    - directory: A string representing the path to test set directory.
    
    Returns:
    - A list of strings representing the paths to test images.
    """
    annotation_lines = []
    path = directory+'/'
    for file in os.listdir(path):
        if file.endswith(".jpg") or file.endswith(".png") or file.endswith(".jpeg"):
            new_path = path+file
            annotation_lines.append(new_path)
    return annotation_lines

def predict(cfg: DictConfig = None) -> None:
    """
    Predicts a class for all the images that are inside a given directory.
    The model used for the predictions can be either a .h5 or .tflite file.

    Args:
        cfg (dict): A dictionary containing the entire configuration file.

    Returns:
        None
    
    Errors:
        The directory containing the images cannot be found.
        The directory does not contain any file.
        An image file can't be loaded.
    """
    
    model_path = cfg.general.model_path
    class_names = cfg.dataset.class_names
    test_images_dir = cfg.prediction.test_files_path
    cpp = cfg.preprocessing
    if cfg.prediction and cfg.prediction.target:
        target = cfg.prediction.target
    else:
        target = "host"
    name_model = os.path.basename(model_path)

    _, model_input_shape = get_model_name_and_its_input_shape(model_path)
    
    print("[INFO] : Making predictions using:")
    print("  model:", model_path)
    print("  images directory:", test_images_dir)

    channels = 1 if cpp.color_mode == "grayscale" else 3
    results_table = []
    file_extension = Path(model_path).suffix

    if test_images_dir:
        image_filenames =  load_test_data(test_images_dir)
    else:
        print("no test set found")

    if file_extension == ".h5":
        # Load the .h5 model
        model = tf.keras.models.load_model(model_path)
    elif file_extension == ".tflite":
        # Load the Tflite model and allocate tensors
        interpreter_quant = tf.lite.Interpreter(model_path=model_path)
        interpreter_quant.allocate_tensors()
        input_details = interpreter_quant.get_input_details()[0]
        input_index_quant = input_details["index"]
        output_index_quant = interpreter_quant.get_output_details()[0]["index"]
        ai_runner_interpreter = ai_runner_interp(target,name_model)
    elif file_extension == ".onnx":
        sess = onnxruntime.InferenceSession(model_path)
        ai_runner_interpreter = ai_runner_interp(target,name_model)

    prediction_result_dir = f'{cfg.output_dir}/predictions/'
    os.makedirs(prediction_result_dir, exist_ok=True)

    for i in range(len(image_filenames)):
        if image_filenames[i].endswith(".jpg") or image_filenames[i].endswith(".png") or image_filenames[i].endswith(".jpeg"):

            print('Inference on image : ',image_filenames[i])
            im_path = os.path.join(test_images_dir, image_filenames[i])

            # Load the image with Tensorflow for the model inference
            try:
                data = tf.io.read_file(im_path)
                img = tf.image.decode_image(data, channels=channels)
            except:
                raise ValueError(f"\nUnable to load image file {im_path}\n"
                                 "Supported image file formats are BMP, GIF, JPEG and PNG.")
            # Resize the image            
            width, height = model_input_shape[1:] if Path(model_path).suffix == '.onnx' else model_input_shape[0:2]
            if cpp.resizing.aspect_ratio == "fit":
                img = tf.image.resize(img, [height, width], method=cpp.resizing.interpolation, preserve_aspect_ratio=False)
            else:
                img = tf.image.resize_with_crop_or_pad(img, height, width)
            # Rescale the image
            img = cpp.rescaling.scale * tf.cast(img, tf.float32) + cpp.rescaling.offset

            # Load the image with OpenCV to print it on screen
            image = cv2.imread(im_path)
            if len(image.shape) != 3:
                image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            height, width, _ = image.shape
            thick = int(0.6 * (height + width) / 600)
            img_name = os.path.splitext(image_filenames[i])[0]

            if file_extension == ".h5":
                img = tf.expand_dims(img, 0)
                scores = model.predict(img)
            elif file_extension == ".tflite":
                image_processed = preprocess_input(img, input_details)
                if target == 'host':
                    interpreter_quant.set_tensor(input_index_quant, image_processed)
                    interpreter_quant.invoke()
                    scores = interpreter_quant.get_tensor(output_index_quant)
                elif target == 'stedgeai_host' or target == 'stedgeai_n6':
                    imagee = ai_interp_input_quant(ai_runner_interpreter,img[None].numpy(),cfg.preprocessing.rescaling.scale, cfg.preprocessing.rescaling.offset,'.tflite')
                    scores = ai_runner_invoke(imagee,ai_runner_interpreter)
                    scores = ai_interp_outputs_dequant(ai_runner_interpreter,[scores])[0]
            elif file_extension == ".onnx":
                image_processed = np.expand_dims(img, 0)
                image_processed = np.transpose(image_processed,[0,3,1,2])
                if target == 'host':
                    scores = predict_onnx(sess, image_processed)
                elif target == 'stedgeai_host' or target == 'stedgeai_n6':
                    imagee = ai_interp_input_quant(ai_runner_interpreter,image_processed,cfg.preprocessing.rescaling.scale, cfg.preprocessing.rescaling.offset,'.onnx')
                    scores = ai_runner_invoke(imagee,ai_runner_interpreter)
                    scores = ai_interp_outputs_dequant(ai_runner_interpreter,[scores])[0]
            else:
                raise TypeError(f"Unknown or unsupported model type. Received path {model_path}")

            # Find the label with the highest score
            scores = np.squeeze(scores)
            if scores.shape == ():
                scores = [scores]
            max_score_index = np.argmax(scores)
            prediction_score = 100 * scores[max_score_index]
            predicted_label = class_names[max_score_index]

            # Add result to the table
            results_table.append([predicted_label, "{:.1f}".format(prediction_score), image_filenames[i]])
            pred_text = str(predicted_label) + ": " +"{:.1f}".format(prediction_score)+ "%"
            cv2.rectangle(image, pt1=(int(0.2*width//2) - int(0.037*width), int(0.2*height//2) - int(2*0.037*height)),pt2=(int(0.2*width//2) + int(len(pred_text)*0.037*width), int(0.2*height//2) + int(0.5*0.037*height)),color=[0, 0, 0], thickness=-1)
            cv2.putText(image, pred_text, (int(0.2*width//2),int(0.2*height//2)), cv2.FONT_HERSHEY_COMPLEX, width/500, (255, 255, 255), thick, lineType=cv2.LINE_AA)

            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            # writing prediction result to the output dir
            # pred_res_filename = f'{prediction_result_dir}/{os.path.basename(img_name)}.png'
            # cv2.imwrite(pred_res_filename,image)
            # if cfg.general.display_figures:
            #     cv2.imshow('image',image)
            #     cv2.waitKey(0)
            #     cv2.destroyAllWindows()
            
            if file_extension == ".h5":
                # For .h5 models, we can directly pass the preprocessed image
                visualize_gradcam(model, im_path, class_names, max_score_index, scores)
     
            # if file_extension == ".h5":
            #     visualize_gradcam(model, im_path, class_names, max_score_index, scores,preprocessed_image=img,target_size=(height, width),
            #      preprocessing_config=cpp)