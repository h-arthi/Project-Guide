import os
import numpy as np
import cv2
import tensorflow as tf
import matplotlib.pyplot as plt

def rgb_to_hsv_to_rgb(image, hue_shift, sat_shift, val_shift):
    # Scale down to [0,1] range
    norm_img = image / 255.0
    
    # Split channels
    R, G, B = tf.split(norm_img, 3, axis=-1)
    
    # Find max/min 
    cmax = tf.maximum(tf.maximum(R, G), B)
    cmin = tf.minimum(tf.minimum(R, G), B)
    diff = cmax - cmin + 1e-7  # epsilon to prevent zero divison
    # Calculate hue 
    is_R_max = tf.cast(tf.equal(cmax, R), tf.float32)
    is_G_max = tf.cast(tf.equal(cmax, G), tf.float32)
    is_B_max = tf.cast(tf.equal(cmax, B), tf.float32)
    # hue calcultion for each range
    h_r = is_R_max * (G - B) / diff
    h_g = is_G_max * ((B - R) / diff + 2.0)
    h_b = is_B_max * ((R - G) / diff + 4.0)
    
    hue = (h_r + h_g + h_b) / 6.0

    # Apply hue shift with proper wrapping
    hue = hue + hue_shift
    #Use floor division instead of modulo as floor is tflite comaptible
    hue = hue - tf.floor(hue)
    # saturation calculation
    sat = tf.where(tf.equal(cmax, 0), tf.zeros_like(cmax), diff/cmax)
    sat = sat + sat_shift
    sat = tf.clip_by_value(sat, 0.0, 1.0)
    # value calculation
    val = cmax
    val = val + val_shiftRGB
    val = tf.clip_by_value(val, 0.0,1.0)
    
    # RGB conversion
    h_6 = hue * 6.0 # this represents h
    h_int = tf.cast(tf.floor(h_6), tf.int32)
    h_int = tf.clip_by_value(h_int, 0, 5) # this represents ⌊h⌋
    
    f = h_6 - tf.cast(h_int, tf.float32)# this represents h - ⌊h⌋
    p = val * (1.0 - sat)# V × (1 - S)
    q = val * (1.0 - (f * sat))# V × (1 − (h - ⌊h⌋) × S)
    t = val * (1.0 - ((1.0 - f) * sat))# V × (1 − (1 − (h - ⌊h⌋)) × S)
    
    # Use integer comparisons
    is_h_0 = tf.cast(tf.equal(h_int, 0), tf.float32)
    is_h_1 = tf.cast(tf.equal(h_int, 1), tf.float32)
    is_h_2 = tf.cast(tf.equal(h_int, 2), tf.float32)
    is_h_3 = tf.cast(tf.equal(h_int, 3), tf.float32)
    is_h_4 = tf.cast(tf.equal(h_int, 4), tf.float32)
    is_h_5 = tf.cast(tf.equal(h_int, 5), tf.float32)
    
    r = (is_h_0 * val + is_h_1 * q + is_h_2 * p + is_h_3 * p + is_h_4 * t + is_h_5 * val)
    g = (is_h_0 * t + is_h_1 * val + is_h_2 * val + is_h_3 * q + is_h_4 * p + is_h_5 * p)
    b = (is_h_0 * p + is_h_1 * p + is_h_2 * t + is_h_3 * val + is_h_4 * val + is_h_5 * q)
    
    rgb = tf.concat([r, g, b], axis=-1)
    HSV = tf.concat([hue, sat, val], axis=-1)
    
    # Scale back to [0,255] range
    return tf.clip_by_value(rgb * 255.0, 0.0, 255.0)

